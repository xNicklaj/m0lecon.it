<?php
// You can use https://onlinephp.io/ to run this code
// Server side PoC

$payload = '<script>alert(1)</script>';
$result = "<h1>0 search results for '".$payload."'</h1>";

echo $result;

/*
The filter input is directly written into the html without any encoding

The resulting page will be rendered with all the tags used in the input
*/