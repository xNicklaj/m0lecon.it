# Server side PoC

search_filter = "' OR 1=1 -- " # normally could be for example 'Lifestyle'
query = "SELECT * FROM data WHERE category='" + search_filter + "';"

print(query) # SELECT * FROM data WHERE category='' OR 1=1 -- ';

# SELECT * FROM data WHERE category='' OR 1=1 -- ' 

# `1=1` is always true, this means that will select all the rows from the table independently from the category

